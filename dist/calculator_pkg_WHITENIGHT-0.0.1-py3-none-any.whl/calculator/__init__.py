# -*- coding: utf-8 -*-

"""
calculator library
-------------------------

This is a proof of concept of a calculator library, written in Python.

"""

__title__ = "calculator"
__version__ = "0.0.1"
__build__ = 0x000001
__author__ = "White Night"
__license__ = "The BSD 3-Clause License"
__copyright__ = "Copyright 2021 White Night"


from .calculator import Calculator
