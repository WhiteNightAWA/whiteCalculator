class BracketsError:
    pass
